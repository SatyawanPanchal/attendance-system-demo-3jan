import Navbar from "../../components/Navbar/Navbar.jsx"

 

 

const Home = () => {
  return (
    <div>
     <Navbar/>
    <h1>i am at home for pricipal or academic incharge
    </h1>
    </div>
  )
}

export default Home
