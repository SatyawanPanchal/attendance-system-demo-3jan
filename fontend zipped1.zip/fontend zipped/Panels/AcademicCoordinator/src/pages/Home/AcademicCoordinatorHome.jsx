 
import Navbar from '../../components/Navbar/Navbar'

const AcademicCoordinatorHome = () => {
  return (
    <div>
      <Navbar/>
      <h1>i am at home of Academic Coordinator</h1>
    </div>
  )
}

export default AcademicCoordinatorHome
