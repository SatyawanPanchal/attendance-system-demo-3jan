 import AddSemAndSections from "../../addSemAndSections/AddSemAndSections"
 
import Navbar from "../../Navbar/Navbar"
 

const SemAndSections = () => {
  return (
    <div>
    <Navbar/>
      <h1>Add Semester and Sections Below</h1>
      <AddSemAndSections/>
      
      
    </div>
  )
}

export default SemAndSections
