import AddDept from "../../addDepartment/AddDept"
import Navbar from "../../Navbar/Navbar"

const Departments = () => {
  return (
    <div>
    <Navbar/>
    <AddDept/>
      
    </div>
  )
}

export default Departments
