 

const AdminPanel = () => {
  return (
    <div>
      <h1>i am in admin panel</h1>
    </div>
  )
}

export default AdminPanel
