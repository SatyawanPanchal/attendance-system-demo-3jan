import Navbar from "../../components/Navbar/Navbar"



const TeachersHome = () => {
  return (
    <div>
      <Navbar />
      <h1>hi i am home page of teachers</h1>
    </div>
  )
}

export default TeachersHome
